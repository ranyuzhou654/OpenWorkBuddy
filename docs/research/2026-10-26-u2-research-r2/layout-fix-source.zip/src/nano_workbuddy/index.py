"""SQLite index (D4). Authoritative here: projects, runs, approvals, inputs not yet in a log, request ids,
and each session's model, settings, name and archived state. Cache rebuilt from the JSONL files: session
titles, leaves and indexed sizes."""

from __future__ import annotations

import contextlib
import hashlib
import json
import sqlite3
import time
from pathlib import Path
from typing import Any

from .log import SessionLog
from .policy import Rule
from .types import USER, new_id, text_of

OWNER = "local"  # single-user for now; every query still scopes by owner (D16)
DEFAULT_SETTINGS = {"preset": "workspace"}

SCHEMA = """
create table if not exists projects(
  id text primary key, owner_id text not null, name text not null, root_path text not null,
  settings_json text not null default '{}', trusted integer not null default 0, created_at real not null,
  unique(owner_id, root_path));
create table if not exists sessions(
  id text primary key, project_id text not null, title text, file_path text not null,
  indexed_bytes integer not null default 0, leaf_id text, model_ref text, settings_json text not null default '{}',
  updated_at real not null, name text, archived_at real);
create table if not exists runs(
  id text primary key, session_id text not null, request_id text unique, status text not null,
  model_ref text, resume_count integer not null default 0, started_at real not null, ended_at real,
  usage_json text);
create table if not exists rules(
  id text primary key, scope text not null, session_id text, action text not null, resource text not null,
  effect text not null, created_at real not null);
create table if not exists approvals(
  id text primary key, session_id text not null, run_id text, call_id text not null, tool text not null,
  args_json text not null, status text not null, feedback text, created_at real not null, resolved_at real,
  preview_json text);
create table if not exists inputs(
  id text primary key, session_id text not null, delivery text not null, content text not null,
  parent_id text, status text not null, created_at real not null, done_at real, extra_json text, run_id text);
create table if not exists schedules(
  id text primary key, name text not null, prompt text not null, session_id text not null, kind text not null,
  at_time text not null, tz text not null, weekdays text not null default '', day text not null default '',
  catch_up text not null default 'once', enabled integer not null default 1, next_run real,
  template_json text not null default '{}', created_at real not null, updated_at real not null,
  last_run_at real, last_outcome text, last_summary text);
create table if not exists occurrences(
  schedule_id text not null, planned_at real not null, missed integer not null default 1, status text not null,
  request_id text, outcome text, summary text, created_at real not null, done_at real, input_id text,
  primary key(schedule_id, planned_at));
create table if not exists requests(
  request_id text primary key, session_id text not null, payload_hash text not null,
  created_at real not null, input_id text);
"""

# Append only: MIGRATIONS[i] upgrades schema version i to i + 1. SCHEMA always describes the latest shape.
MIGRATIONS = [
    "alter table sessions add column settings_json text not null default '{}'",  # phase 2
    "alter table sessions add column name text",  # renamed by the user; shown instead of the title
    "alter table sessions add column archived_at real",
    "update projects set trusted=1",  # projects added before trust existed were all chosen by the user
    "alter table inputs add column extra_json text",  # attachments of a pending message (M1)
    "alter table approvals add column preview_json text",  # frozen payload/account/hash shown to the user (R-A)
    "alter table requests add column input_id text",
    "alter table inputs add column run_id text",
    "alter table occurrences add column input_id text",
    """update requests set input_id=(select id from inputs where inputs.session_id=requests.session_id
       and json_extract(extra_json,'$.request_id')=requests.request_id order by created_at limit 1)
       where input_id is null""",
    """update inputs set run_id=(select id from runs where runs.session_id=inputs.session_id
       and runs.request_id=json_extract(inputs.extra_json,'$.request_id')) where run_id is null""",
]


class Index:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path, isolation_level=None)
        self.db.row_factory = sqlite3.Row
        self.db.execute("pragma journal_mode=wal")
        self._migrate()

    def _migrate(self) -> None:
        existed = self._one("select 1 from sqlite_master where type='table' and name='sessions'") is not None
        self.db.executescript(SCHEMA)  # creates whatever is missing, at the latest shape
        version = self.db.execute("pragma user_version").fetchone()[0] if existed else len(MIGRATIONS)
        for sql in MIGRATIONS[version:]:
            try:
                self.db.execute(sql)
            except sqlite3.OperationalError as e:  # a database written by a build that had the column already
                if "duplicate column" not in str(e):
                    raise
        self.db.execute(f"pragma user_version={len(MIGRATIONS)}")

    def _one(self, sql: str, *args: Any) -> dict[str, Any] | None:
        row = self.db.execute(sql, args).fetchone()
        return dict(row) if row else None

    def _all(self, sql: str, *args: Any) -> list[dict[str, Any]]:
        return [dict(r) for r in self.db.execute(sql, args)]

    @contextlib.contextmanager
    def transaction(self):
        self.db.execute("begin immediate")
        try:
            yield
            self.db.execute("commit")
        except BaseException:
            self.db.execute("rollback")
            raise

    # projects

    def project_at(self, root: Path) -> dict[str, Any] | None:
        return self._one("select * from projects where owner_id=? and root_path=?", OWNER, str(root.resolve()))

    def project_for(self, root: Path, trusted: bool = False) -> dict[str, Any]:
        """The project at root, created (with that trust) if it is new; an existing one keeps its trust."""
        if p := self.project_at(root):
            return p
        self.db.execute("insert into projects(id, owner_id, name, root_path, trusted, created_at) values (?,?,?,?,?,?)",
                        (new_id("p"), OWNER, root.resolve().name, str(root.resolve()), int(trusted), time.time()))
        return self.project_at(root)

    def project(self, project_id: str) -> dict[str, Any] | None:
        return self._one("select * from projects where id=? and owner_id=?", project_id, OWNER)

    def projects(self) -> list[dict[str, Any]]:
        return self._all("select * from projects where owner_id=? order by created_at", OWNER)

    def update_project(self, project_id: str, name: str | None = None, trusted: bool | None = None,
                       no_index: bool | None = None) -> None:
        self.db.execute("update projects set name=coalesce(?, name), trusted=coalesce(?, trusted) where id=?",
                        (name, None if trusted is None else int(trusted), project_id))
        if no_index is not None:
            settings = {**json.loads(self.project(project_id)["settings_json"]), "no_index": no_index}
            self.db.execute("update projects set settings_json=? where id=?", (json.dumps(settings), project_id))

    def delete_project(self, project_id: str) -> None:
        """Only the index row; the caller deletes the sessions first."""
        self.db.execute("delete from projects where id=?", (project_id,))

    # sessions

    def sync_session(self, log: SessionLog, model_ref: str | None = None) -> None:
        first_user = next((e for e in log.entries.values() if e.type == USER), None)
        if first_user:  # the typed text, not the attachments' contents; a message of attachments only: their names
            typed = text_of([b for b in first_user.data["content"] if "attachment" not in b]).strip()
            names = ", ".join(a["name"] for a in first_user.data.get("attachments", ()))
            title = (typed or names)[:80] or None
        else:
            title = None
        self.db.execute(
            """insert into sessions(id, project_id, title, file_path, indexed_bytes, leaf_id, model_ref, updated_at)
               values (?,?,?,?,?,?,?,?)
               on conflict(id) do update set title=excluded.title, file_path=excluded.file_path,
                 indexed_bytes=excluded.indexed_bytes,
                 leaf_id=excluded.leaf_id, model_ref=coalesce(excluded.model_ref, sessions.model_ref),
                 updated_at=excluded.updated_at""",
            (log.id, log.header["project_id"], title, str(log.file), log.file.stat().st_size,
             log.leaf_id, model_ref, time.time()))

    @staticmethod
    def _session(row: dict[str, Any] | None) -> dict[str, Any] | None:
        if row is not None:
            stored = json.loads(row.pop("settings_json"))
            if "mode" in stored:  # phase 2 settings: confirm / trust
                stored = {"preset": "trust" if stored["mode"] == "trust" else "workspace"}
            row["settings"] = {**DEFAULT_SETTINGS, **stored}
            row["title"] = row.pop("name") or row["title"]
        return row

    def session(self, session_id: str) -> dict[str, Any] | None:
        return self._session(self._one("select * from sessions where id=?", session_id))

    def sessions(self, project_id: str) -> list[dict[str, Any]]:
        rows = self._all("select * from sessions where project_id=? order by updated_at desc", project_id)
        return [self._session(r) for r in rows]

    def last_runs(self, project_id: str) -> dict[str, dict[str, Any]]:
        """The most recent run per session, used by the sidebar's status dot."""
        rows = self._all(
            """select r.session_id, r.id, r.status, r.ended_at from runs r
               join sessions s on s.id=r.session_id
               where s.project_id=? and r.id=(select id from runs latest
                 where latest.session_id=r.session_id order by latest.started_at desc, latest.id desc limit 1)""",
            project_id)
        return {r.pop("session_id"): r for r in rows}

    def rename_session(self, session_id: str, name: str | None) -> None:
        """None goes back to the title taken from the first message."""
        self.db.execute("update sessions set name=? where id=?", (name, session_id))

    def archive_session(self, session_id: str, archived: bool) -> None:
        self.db.execute("update sessions set archived_at=? where id=?", (time.time() if archived else None, session_id))

    def delete_session(self, session_id: str) -> None:
        for table, key in (("sessions", "id"), ("runs", "session_id"), ("rules", "session_id"),
                           ("approvals", "session_id"), ("inputs", "session_id"), ("requests", "session_id"),
                           ("schedules", "session_id")):
            self.db.execute(f"delete from {table} where {key}=?", (session_id,))

    def update_settings(self, session_id: str, patch: dict[str, Any]) -> dict[str, Any]:
        settings = {**self.session(session_id)["settings"], **patch}
        self.db.execute("update sessions set settings_json=? where id=?", (json.dumps(settings), session_id))
        return settings

    def reindex(self, sessions_dir: Path) -> int:
        """Bring the sessions table up to date with JSONL files written after the last sync."""
        known = {r["file_path"]: r["indexed_bytes"] for r in self._all("select file_path, indexed_bytes from sessions")}
        n = 0
        for f in sessions_dir.glob("*/*.jsonl"):
            if known.get(str(f)) != f.stat().st_size:
                self.sync_session(SessionLog.open(f))
                n += 1
        return n

    # runs

    def start_run(self, session_id: str, request_id: str | None, model_ref: str,
                  input_id: str | None = None) -> tuple[dict[str, Any], bool]:
        """Returns (run, created). A repeated request_id returns the existing run."""
        with self.transaction():
            if request_id and (r := self._one("select * from runs where request_id=?", request_id)):
                if r["session_id"] != session_id:
                    raise ValueError("request_id belongs to another session")
                return r, False
            run_id = new_id("r")
            self.db.execute("insert into runs(id, session_id, request_id, status, model_ref, started_at)"
                            " values (?,?,?,?,?,?)", (run_id, session_id, request_id, "running", model_ref,
                                                      time.time()))
            if input_id:
                self.bind_input(input_id, run_id)
            return self._one("select * from runs where id=?", run_id), True

    def finish_run(self, run_id: str, status: str, usage: dict[str, int] | None = None) -> None:
        self.db.execute("update runs set status=?, ended_at=?, usage_json=? where id=?",
                        (status, time.time(), json.dumps(usage or {}), run_id))

    def unfinished_runs(self, session_id: str | None = None) -> list[dict[str, Any]]:
        """Runs a crash ('running') or a server shutdown ('interrupted') left behind."""
        sql = "select * from runs where status in ('running', 'interrupted')"
        if session_id:
            return self._all(sql + " and session_id=? order by started_at", session_id)
        return self._all(sql + " order by started_at")

    def usage(self, since: float) -> list[dict[str, Any]]:
        """Finished runs since a time: when, which model, and its token counts."""
        rows = self._all("select started_at, model_ref, usage_json from runs"
                         " where started_at>=? and usage_json is not null", since)
        return [{"at": r["started_at"], "model": r["model_ref"], **json.loads(r["usage_json"])} for r in rows]

    def bump_resume(self, run_id: str) -> int:
        self.db.execute("update runs set resume_count=resume_count+1 where id=?", (run_id,))
        return self._one("select resume_count from runs where id=?", run_id)["resume_count"]

    # requests and inputs (messages accepted from a client)

    def claim_request(self, request_id: str, session_id: str, payload: str) -> str:
        """Legacy import/probe helper. Application submissions must use atomic accept_input instead."""
        digest = hashlib.sha256(payload.encode()).hexdigest()
        cur = self.db.execute("insert or ignore into requests(request_id, session_id, payload_hash, created_at)"
                              " values (?,?,?,?)", (request_id, session_id, digest, time.time()))
        if cur.rowcount:
            return "new"
        row = self._one("select * from requests where request_id=?", request_id)
        return "duplicate" if row["session_id"] == session_id and row["payload_hash"] == digest else "conflict"

    def request_input(self, request_id: str | None, session_id: str, payload: str,
                      legacy_payload: str | None = None) -> dict | None:
        if not request_id:
            return None
        row = self._one("select * from requests where request_id=?", request_id)
        if row is None:
            return None
        hashes = {hashlib.sha256(p.encode()).hexdigest() for p in (payload, legacy_payload) if p is not None}
        if row["session_id"] != session_id or row["payload_hash"] not in hashes:
            raise ValueError(f"request_id {request_id} was already used for a different session or payload")
        return self.input(row["input_id"]) if row["input_id"] else None

    def accept_input(self, session_id: str, delivery: str, content: str, parent_id: str | None = None,
                     extra: dict | None = None, *, request_id: str | None = None,
                     payload: str = "", legacy_payload: str | None = None) -> tuple[dict, bool]:
        """Request IDs are home-wide and bind session + text + parent + attachment IDs + requested delivery.
        The request and its input commit together. A pre-R-B orphan claim can be repaired on a matching retry.
        """
        with self.transaction():
            return self._accept_input(session_id, delivery, content, parent_id, extra, request_id, payload,
                                      legacy_payload)

    def _accept_input(self, session_id, delivery, content, parent_id, extra, request_id, payload, legacy_payload=None):
        existing = self.request_input(request_id, session_id, payload, legacy_payload)
        if existing:
            return existing, False
        if request_id:
            self.db.execute("insert or ignore into requests(request_id,session_id,payload_hash,created_at)"
                            " values (?,?,?,?)", (request_id, session_id, hashlib.sha256(payload.encode()).hexdigest(),
                                                  time.time()))
        if request_id:
            extra = {**(extra or {}), "request_id": request_id}
        iid = self.add_input(session_id, delivery, content, parent_id, extra)
        if request_id:
            self.db.execute("update requests set input_id=?,payload_hash=? where request_id=?",
                            (iid, hashlib.sha256(payload.encode()).hexdigest(), request_id))
        return self.input(iid), True

    def input(self, input_id: str) -> dict | None:
        return self._one("select * from inputs where id=?", input_id)

    def bind_input(self, input_id: str, run_id: str) -> None:
        self.db.execute("update inputs set run_id=? where id=? and run_id is null", (run_id, input_id))

    def add_input(self, session_id: str, delivery: str, content: str, parent_id: str | None = None,
                  extra: dict[str, Any] | None = None) -> str:
        """A message the client sent, made durable before the client is told it was accepted. It stays
        pending until it is in the session log (consumed) or handed back to the user (dropped).
        extra: its attachments, as they will appear in the user entry."""
        input_id = new_id("in")
        self.db.execute("insert into inputs(id, session_id, delivery, content, parent_id, status, created_at,"
                        " extra_json) values (?,?,?,?,?,?,?,?)",
                        (input_id, session_id, delivery, content, parent_id, "pending", time.time(),
                         json.dumps(extra, ensure_ascii=False) if extra else None))
        return input_id

    def finish_input(self, input_id: str, status: str, run_id: str | None = None) -> None:
        self.db.execute("update inputs set status=?, done_at=?, run_id=coalesce(run_id,?)"
                        " where id=? and status='pending'", (status, time.time(), run_id, input_id))

    def pending_inputs(self, session_id: str | None = None) -> list[dict[str, Any]]:
        sql = "select * from inputs where status='pending'"
        if session_id:
            return self._all(sql + " and session_id=? order by created_at, rowid", session_id)
        return self._all(sql + " order by created_at, rowid")

    # schedules (M3): the rule and state live here; the work happens in the schedule's own session

    SCHEDULE_FIELDS = ("name", "prompt", "kind", "at_time", "tz", "weekdays", "day", "catch_up", "enabled",
                       "next_run", "template_json", "last_run_at", "last_outcome", "last_summary")

    def add_schedule(self, session_id: str, **fields: Any) -> dict[str, Any]:
        sid, now = new_id("sch"), time.time()
        cols = {k: v for k, v in fields.items() if k in self.SCHEDULE_FIELDS}
        names = ", ".join(cols)
        self.db.execute(f"insert into schedules(id, session_id, created_at, updated_at, {names}) values "
                        f"(?,?,?,?,{','.join('?' * len(cols))})", (sid, session_id, now, now, *cols.values()))
        return self.schedule(sid)

    def update_schedule(self, schedule_id: str, **fields: Any) -> dict[str, Any] | None:
        cols = {k: v for k, v in fields.items() if k in self.SCHEDULE_FIELDS}
        if cols:
            sets = ", ".join(f"{k}=?" for k in cols)
            self.db.execute(f"update schedules set {sets}, updated_at=? where id=?",
                            (*cols.values(), time.time(), schedule_id))
        return self.schedule(schedule_id)

    def schedule(self, schedule_id: str) -> dict[str, Any] | None:
        return self._one("select * from schedules where id=?", schedule_id)

    def schedules(self) -> list[dict[str, Any]]:
        return self._all("select * from schedules order by created_at")

    def schedule_for_session(self, session_id: str) -> dict[str, Any] | None:
        return self._one("select * from schedules where session_id=?", session_id)

    def delete_schedule(self, schedule_id: str) -> None:
        self.db.execute("delete from schedules where id=?", (schedule_id,))
        self.db.execute("delete from occurrences where schedule_id=?", (schedule_id,))

    def claim_occurrence(self, schedule_id: str, planned_at: float, missed: int, status: str,
                         request_id: str | None = None) -> bool:
        """Record that this occurrence is being handled. False if it already was: the (schedule, planned
        instant) key is what keeps a restart, or a second server, from running it twice."""
        cur = self.db.execute("insert or ignore into occurrences(schedule_id, planned_at, missed, status, request_id,"
                              " created_at) values (?,?,?,?,?,?)",
                              (schedule_id, planned_at, missed, status, request_id, time.time()))
        return cur.rowcount == 1

    def accept_occurrence(self, row: dict, planned: float, missed: int, content: str, request_id: str,
                          *, advance: bool = False, next_run: float | None = None, now: float = 0,
                          manual: bool = False) -> dict:
        """Occurrence, accepted input and schedule advancement are one durable transaction."""
        with self.transaction():
            if manual:
                import math

                while self._one("select 1 from occurrences where schedule_id=? and planned_at=?", row["id"], planned):
                    planned = math.nextafter(planned, float("inf"))
            self.claim_occurrence(row["id"], planned, missed, "submitted", request_id)
            occ = self._one("select * from occurrences where schedule_id=? and planned_at=?", row["id"], planned)
            if occ["status"] == "submitted" and not occ["input_id"]:
                extra = {"request_id": occ["request_id"]}
                payload = json.dumps({"schedule": row["id"], "planned": planned}, sort_keys=True)
                accepted = self._one("select * from inputs where session_id=?"
                                     " and json_extract(extra_json,'$.request_id')=? order by created_at limit 1",
                                     row["session_id"], occ["request_id"])
                if accepted is None:
                    accepted, _ = self._accept_input(row["session_id"], "run", content, None, extra,
                                                      occ["request_id"], payload)
                self.db.execute("update occurrences set input_id=? where schedule_id=? and planned_at=?",
                                (accepted["id"], row["id"], planned))
                occ["input_id"] = accepted["id"]
            if advance:
                self.update_schedule(row["id"], next_run=next_run, last_run_at=now)
            return occ

    def finish_occurrence(self, schedule_id: str, planned_at: float, outcome: str, summary: str = "") -> None:
        self.db.execute("update occurrences set status='done', outcome=?, summary=?, done_at=? "
                        "where schedule_id=? and planned_at=?",
                        (outcome, summary, time.time(), schedule_id, planned_at))

    def occurrences(self, schedule_id: str | None = None, status: str | None = None,
                    limit: int = 50) -> list[dict[str, Any]]:
        sql, args = "select * from occurrences where 1=1", []
        if schedule_id:
            sql, args = sql + " and schedule_id=?", [*args, schedule_id]
        if status:
            sql, args = sql + " and status=?", [*args, status]
        return self._all(sql + " order by planned_at desc limit ?", *args, limit)

    def run_for_request(self, request_id: str) -> dict[str, Any] | None:
        return self._one("select * from runs where request_id=?", request_id)

    # rules approved by the user ("always allow")

    def add_rule(self, session_id: str, rule: Rule) -> None:
        self.db.execute("insert into rules(id, scope, session_id, action, resource, effect, created_at)"
                        " values (?,?,?,?,?,?,?)", (new_id("rule"), "session", session_id, rule.action, rule.resource,
                                                     rule.effect, time.time()))

    def session_rules(self, session_id: str) -> list[Rule]:
        rows = self._all("select * from rules where scope='session' and session_id=? order by created_at", session_id)
        return [Rule(r["action"], r["resource"], r["effect"]) for r in rows]

    # approvals

    def add_approval(self, approval_id: str, session_id: str, run_id: str | None, call: dict[str, Any],
                     preview: Any = None) -> None:
        self.db.execute("insert into approvals(id, session_id, run_id, call_id, tool, args_json, status, created_at,"
                        " preview_json) values (?,?,?,?,?,?,?,?,?)", (approval_id, session_id, run_id,
                                                      call["id"], call["name"],
                                                      json.dumps(call["args"], ensure_ascii=False), "pending",
                                                      time.time(), json.dumps(preview, ensure_ascii=False)))

    def resolve_approval(self, approval_id: str, status: str, feedback: str | None = None) -> None:
        self.db.execute("update approvals set status=?, feedback=?, resolved_at=? where id=? and status='pending'",
                        (status, feedback, time.time(), approval_id))

    def expire_pending_approvals(self) -> None:
        """At startup nobody is waiting on old approvals; resumed runs ask again."""
        self.db.execute("update approvals set status='expired', resolved_at=? where status='pending'", (time.time(),))
