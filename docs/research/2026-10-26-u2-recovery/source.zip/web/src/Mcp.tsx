import { useEffect, useState } from "react";
import { api, type Exposure, type FeishuStatus, type KeyStatus, type McpSpec, type McpView, type SettingsView } from "./api";
import { Select } from "./Select";
import { useConfirm } from "./ui";

// MCP servers live in [mcp.NAME] of config.toml and are shared by all projects. stdio servers run in
// the sandbox: they may use the network, but write only to a temp dir and the paths listed here.

const TEMPLATES: { label: string; name: string; spec: Partial<McpSpec> }[] = [
  { label: "文件系统（npx）", name: "filesystem", spec: {
    command: "npx", args: ["-y", "@modelcontextprotocol/server-filesystem", "~/Documents"],
    writable: ["~/.npm", "~/Documents"] } },
  { label: "网页抓取 Fetch（uvx）", name: "fetch", spec: {
    command: "uvx", args: ["mcp-server-fetch"], writable: ["~/.cache/uv", "~/.local/share/uv"] } },
  { label: "Context7 文档（远程）", name: "context7", spec: { url: "https://mcp.context7.com/mcp" } },
  { label: "GitHub（远程，需令牌）", name: "github", spec: {
    url: "https://api.githubcopilot.com/mcp/", headers: { Authorization: "Bearer 你的令牌" } } },
];

const EXPOSURES: Record<Exposure, string> = {
  auto: "自动（工具多时延迟加载）", direct: "直接声明", deferred: "延迟加载（tool_search）",
};

const EMPTY: McpSpec = {
  command: "", args: [], env: {}, url: "", headers: {}, enabled: true, exposure: "auto", sandbox: true,
  network: true, writable: [], timeout: 300, description: "",
};

const isRef = (v: string) => /^(env|keyring|secret):.+$/.test(v);

// Feishu through the official lark-cli, as the user. Reads run freely; the listed writes are approved per call.
function FeishuCard({ view, save }: { view: SettingsView; save: (p: Promise<SettingsView>) => Promise<boolean> }) {
  const [status, setStatus] = useState<FeishuStatus | "loading" | null>(null);
  const check = () => {
    setStatus("loading");
    api.feishuStatus().then(setStatus).catch((e) => setStatus({ available: false, cli: view.feishu.cli, error: String(e) }));
  };
  useEffect(check, [view.feishu.cli]); // eslint-disable-line react-hooks/exhaustive-deps
  const s = status === "loading" ? null : status;
  return (
    <div className="card">
      <div className="card-head">
        <b>飞书</b>
        <span className="tag">官方 lark-cli · 以你本人身份</span>
        {status === "loading" ? <span className="note">检查中…</span>
          : !s?.available ? <span className="key missing">未找到 {view.feishu.cli}</span>
          : s.user?.available ? <span className="key ok">✓ {s.user.name} · {s.version}</span>
          : <span className="key missing">未授权：需要以本人身份登录</span>}
        <span className="grow" />
        <label className="check"><input type="checkbox" checked={view.feishu.enabled}
          onChange={(e) => save(api.putFeishu({ enabled: e.target.checked }))} />启用</label>
      </div>
      <p className="note">
        助手可以直接搜索和阅读你有权限的文档、知识库、表格，查看日程和任务，读取群聊；发送/回复消息、新建/修改文档、导入文件这几类写操作
        每次都会弹出审批卡，显示账户、目标、内容和 dry-run 预览，不能“总是允许”。删除、改权限等高风险操作不开放。令牌由 lark-cli 存在系统钥匙串里，助手和模型拿不到。
      </p>
      {s?.available && !s.user?.available && (
        <div className="note warn-line">先按下方步骤授权文档和日历读取，再点“重新检查”。</div>
      )}
      <details className="note">
        <summary>如何配置飞书文档和日历读取</summary>
        <ol>
          <li>确认终端可运行 <code>lark-cli --version</code>。首次使用且尚未配置应用时，运行 <code>lark-cli config init --new</code>；已有应用配置可跳过。</li>
          <li>以本人身份授权文档与日历只读权限：<br /><code>lark-cli auth login --scope "docx:document:readonly calendar:calendar:readonly"</code><br />
            按终端提示在飞书确认。若提示应用未开通这些权限，先由应用管理员开通，随后重新授权。</li>
          <li>回到此处点“重新检查”，确认显示本人账户，再勾选“启用”。已有会话在下一次运行时生效。</li>
          <li>在对话中明确提供允许读取的文档链接或日历名称。只读授权不包含发布权限；后续发布测试需另设测试位置，并逐次确认审批内容。</li>
        </ol>
        <p>飞书登录由官方 CLI 管理，不需要将 App Secret 或访问令牌填入此页面。</p>
      </details>
      <div className="row"><button onClick={check}>重新检查</button></div>
    </div>
  );
}

// A browser with its own profile, through the official Playwright MCP server.
function BrowserCard({ view, save }: { view: SettingsView; save: (p: Promise<SettingsView>) => Promise<boolean> }) {
  const b = view.browser;
  const state = { connected: "运行中", error: "启动失败", idle: "下次运行时启动", disabled: "未启用" }[b.status];
  return (
    <div className="card">
      <div className="card-head">
        <b>浏览器</b>
        <span className="tag">Playwright · 独立配置</span>
        <span className={`key ${b.status === "error" ? "missing" : b.status === "connected" ? "ok" : ""}`} title={b.error}>{state}</span>
        <span className="grow" />
        <label className="check"><input type="checkbox" checked={b.headless} disabled={!b.enabled}
          onChange={(e) => save(api.putBrowser({ headless: e.target.checked }))} />不显示窗口</label>
        <label className="check"><input type="checkbox" checked={b.enabled}
          onChange={(e) => save(api.putBrowser({ enabled: e.target.checked }))} />启用</label>
      </div>
      <p className="note">
        助手使用一个单独的浏览器配置（<code>{b.profile}</code>），不碰你日常 Chrome 的 cookie；需要登录的网站，在它弹出的窗口里手动登录一次即可。
        读取页面不询问；打开网站按站点确认；点击、输入、上传、运行页面脚本每次确认。同一时间只有一个会话能操作浏览器。
      </p>
      {b.error && <div className="note warn-line">{b.error}</div>}
    </div>
  );
}

export function McpSection({ view, save, onError }: {
  view: SettingsView;
  save: (p: Promise<SettingsView>) => Promise<boolean>;
  onError: (m: string) => void;
}) {
  const [editing, setEditing] = useState<McpView | "new" | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const confirm = useConfirm();

  const connect = async (name: string) => {
    setBusy(name);
    try {
      await save(api.connectMcp(name));
      setOpen((o) => ({ ...o, [name]: true }));
    } finally {
      setBusy(null);
    }
  };

  const form = (initial: McpView | null) => (
    <McpForm key={initial?.name ?? "new"} initial={initial} onCancel={() => setEditing(null)} onError={onError}
      onSave={async (name, body) => (await save(api.putMcp(name, body))) && setEditing(null)} />
  );

  return (
    <>
      <h2>飞书与浏览器</h2>
      <FeishuCard view={view} save={save} />
      <BrowserCard view={view} save={save} />
      <h2>连接器（MCP 服务器）</h2>
      <p className="note">
        所有项目共用。每次运行开始时连接已启用的服务器，关掉的服务器从下一次运行起不再出现。MCP 工具和内置工具走同一套权限：
        默认每次调用都要你确认，可以在审批时选“本会话总是允许此工具”。本机（stdio）服务器默认在沙箱里运行：能联网，但只能写临时目录和下面列出的路径。
      </p>
      {view.mcp.map((m) =>
        editing !== "new" && editing?.name === m.name ? form(m) : (
          <div key={m.name} className="card">
            <div className="card-head">
              <label className="check"><input type="checkbox" checked={m.enabled}
                onChange={(e) => save(api.enableMcp(m.name, e.target.checked))} /></label>
              <b>{m.name}</b>
              <span className="tag">{m.url ? "远程 HTTP" : "本机 stdio"}</span>
              <Status m={m} busy={busy === m.name} />
              {!m.url && !m.sandbox && <span className="key missing">无沙箱</span>}
              <span className="note">{EXPOSURES[m.exposure]}</span>
            </div>
            <code className="cmd">{m.url || [m.command, ...m.args].join(" ")}</code>
            {Object.entries(m.keys).map(([k, st]) => <KeyLine key={k} name={k} k={st} />)}
            <div className="row">
              <button onClick={() => connect(m.name)} disabled={!m.enabled || busy === m.name}>
                {m.status === "connected" ? "重新连接" : "连接测试"}
              </button>
              {m.tools.length > 0 && (
                <button onClick={() => setOpen((o) => ({ ...o, [m.name]: !o[m.name] }))}>
                  {open[m.name] ? "收起工具" : `查看 ${m.tools.length} 个工具`}
                </button>
              )}
              <button onClick={() => setEditing(m)}>编辑</button>
              <button className="danger" onClick={() => confirm({ title: "删除连接器", message: `删除 MCP 服务器 ${m.name}？它保存的密钥也会删除。`, confirmLabel: "删除", danger: true }).then((ok) => {
                if (ok) void save(api.deleteMcp(m.name));
              })}>删除</button>
            </div>
            {m.status === "error" && <div className="note warn-line">{m.error}</div>}
            {open[m.name] && (
              <ul className="mcp-tools">
                {m.tools.map((t) => <li key={t.name}><code>{t.name}</code> {t.description}</li>)}
              </ul>
            )}
          </div>
        ),
      )}
      {editing === "new" ? form(null) : (
        <button className="link" onClick={() => setEditing("new")}>＋ 添加 MCP 服务器</button>
      )}
    </>
  );
}

function Status({ m, busy }: { m: McpView; busy: boolean }) {
  if (busy) return <span className="note">连接中…</span>;
  switch (m.status) {
    case "connected": return <span className="key ok">✓ 已连接 · {m.tools.length} 个工具</span>;
    case "error": return <span className="key missing">✗ 连接失败</span>;
    case "disabled": return <span className="note">已停用</span>;
    default: return <span className="note">未启动（下次运行时连接）</span>;
  }
}

function KeyLine({ name, k }: { name: string; k: KeyStatus }) {
  return (
    <div className="note">
      {name}：{k.set ? <span className="key ok">✓ {k.hint}</span> : <span className="key missing">未设置</span>}
      {" "}<span>（{k.source}:{k.name}）</span>
    </div>
  );
}

// KEY=VALUE lines <-> object (headers use "Name: value")
function toLines(o: Record<string, string>, sep: string): string {
  return Object.entries(o).map(([k, v]) => `${k}${sep}${v}`).join("\n");
}
function fromLines(s: string, sep: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const line of s.split("\n")) {
    const i = line.indexOf(sep);
    if (i > 0) out[line.slice(0, i).trim()] = line.slice(i + sep.length).trim();
  }
  return out;
}
const list = (s: string) => s.split("\n").map((x) => x.trim()).filter(Boolean);

function McpForm({ initial, onSave, onCancel, onError }: {
  initial: McpView | null;
  onSave: (name: string, body: McpSpec & { secret_keys: string[] }) => void;
  onCancel: () => void;
  onError: (m: string) => void;
}) {
  const start = initial ?? EMPTY;
  const [name, setName] = useState(initial?.name ?? "");
  const [remote, setRemote] = useState(!!start.url);
  const [spec, setSpec] = useState<McpSpec>({ ...EMPTY, ...start });
  const [args, setArgs] = useState(start.args.join("\n"));
  const [env, setEnv] = useState(toLines(start.env, "="));
  const [headers, setHeaders] = useState(toLines(start.headers, ": "));
  const [writable, setWritable] = useState(start.writable.join("\n"));
  const [asSecrets, setAsSecrets] = useState(true);
  const [template, setTemplate] = useState("");
  const set = <K extends keyof McpSpec>(k: K, v: McpSpec[K]) => setSpec({ ...spec, [k]: v });

  const pick = (i: number) => {
    const t = TEMPLATES[i];
    if (!t) return;
    const s = { ...EMPTY, ...t.spec };
    setName(t.name); setRemote(!!s.url); setSpec(s);
    setArgs(s.args.join("\n")); setEnv(toLines(s.env, "=")); setHeaders(toLines(s.headers, ": "));
    setWritable(s.writable.join("\n"));
  };

  const submit = () => {
    const e = remote ? {} : fromLines(env, "=");
    const h = remote ? fromLines(headers, ":") : {};
    if (Object.values(h).some((v) => v.includes("你的令牌"))) return onError("请先把请求头里的“你的令牌”换成真实令牌");
    const body: McpSpec = {
      ...spec, command: remote ? "" : spec.command, url: remote ? spec.url : "", args: remote ? [] : list(args),
      env: e, headers: h, writable: remote ? [] : list(writable),
    };
    const secretKeys = asSecrets ? Object.entries({ ...e, ...h }).filter(([, v]) => v && !isRef(v)).map(([k]) => k) : [];
    onSave(name, { ...body, secret_keys: secretKeys });
  };

  return (
    <div className="card form">
      {!initial && (
        <label>从模板开始
          <Select value={template} label="从模板开始"
            options={[
              { value: "", label: "选择…", disabled: true },
              ...TEMPLATES.map((t, i) => ({ value: String(i), label: t.label })),
            ]}
            onChange={(next) => { setTemplate(next); pick(Number(next)); }} />
        </label>
      )}
      <label>名称<input value={name} disabled={!!initial} onChange={(e) => setName(e.target.value)} placeholder="如 github" /></label>
      <label>类型
        <Select value={remote ? "http" : "stdio"} label="类型"
          options={[
            { value: "stdio", label: "本机命令（stdio）" },
            { value: "http", label: "远程地址（Streamable HTTP）" },
          ]}
          onChange={(next) => setRemote(next === "http")} />
      </label>
      {remote ? (
        <>
          <label>地址<input value={spec.url} onChange={(e) => set("url", e.target.value)} placeholder="https://…/mcp" /></label>
          <label>请求头（每行 名称: 值）
            <textarea rows={2} value={headers} onChange={(e) => setHeaders(e.target.value)} placeholder="Authorization: Bearer …" />
          </label>
        </>
      ) : (
        <>
          <label>命令<input value={spec.command} onChange={(e) => set("command", e.target.value)} placeholder="npx / uvx / 可执行文件路径" /></label>
          <label>参数（每行一个）<textarea rows={3} value={args} onChange={(e) => setArgs(e.target.value)} /></label>
          <label>环境变量（每行 KEY=值）<textarea rows={2} value={env} onChange={(e) => setEnv(e.target.value)} placeholder="GITHUB_TOKEN=…" /></label>
          <label className="check"><input type="checkbox" checked={spec.sandbox} onChange={(e) => set("sandbox", e.target.checked)} />在沙箱里运行（推荐）</label>
          {spec.sandbox ? (
            <>
              <label className="check"><input type="checkbox" checked={spec.network} onChange={(e) => set("network", e.target.checked)} />允许联网</label>
              <label>可写路径（每行一个）
                <textarea rows={2} value={writable} onChange={(e) => setWritable(e.target.value)} placeholder="~/.npm（npx 的缓存）" />
              </label>
            </>
          ) : <div className="note warn-line">不进沙箱：服务器以你的全部权限运行，只对完全信任的服务器这样做。</div>}
        </>
      )}
      <label className="check"><input type="checkbox" checked={asSecrets} onChange={(e) => setAsSecrets(e.target.checked)} />
        把{remote ? "请求头" : "环境变量"}的值存为密钥（~/.nwb/secrets.json，配置文件里只留引用）</label>
      <label>工具声明
        <Select value={spec.exposure} label="工具声明"
          options={Object.entries(EXPOSURES).map(([value, label]) => ({ value, label }))}
          onChange={(next) => set("exposure", next as Exposure)} />
      </label>
      <label>一句话说明<input value={spec.description} onChange={(e) => set("description", e.target.value)}
        placeholder="延迟加载时告诉模型这个服务器能做什么（可选）" /></label>
      <label>单次调用超时（秒）<input type="number" value={spec.timeout} onChange={(e) => set("timeout", Number(e.target.value))} /></label>
      <div className="row">
        <button onClick={onCancel}>取消</button>
        <button className="primary" disabled={!name || (remote ? !spec.url : !spec.command)} onClick={submit}>保存</button>
      </div>
    </div>
  );
}
